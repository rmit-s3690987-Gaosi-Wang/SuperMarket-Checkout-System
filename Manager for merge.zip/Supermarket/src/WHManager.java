public class WHManager extends Employee {
    public WHManager(String employeeID, String password, String firstName, String lastName) {
        super(employeeID, password, firstName, lastName);
    }
}
