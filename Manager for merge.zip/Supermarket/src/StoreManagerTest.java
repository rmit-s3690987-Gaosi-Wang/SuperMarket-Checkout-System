import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StoreManagerTest {
 StoreManager steve;
 Product a;
    @BeforeEach
    void setUp() {
        steve = new StoreManager("E12345", "123456", "Steve", "Anderson");

        a = new Product("ABC002", "APPLE", 5, 4.5,
                40, 4, 200, 100, 100, "EA", false, "woolworth");
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void alterPrice() {
        assertEquals(a.getUnitPrice(),5);
        steve.alterPrice(a, 7.0);
        assertEquals(7.0,a.getUnitPrice());
    }

    @Test
    void setStockLevel() {
        steve.setStockLevel(a,20);
        assertEquals(20,a.getReplenishLine());
        steve.setStockLevel(a,40);
        assertEquals(40,a.getReplenishLine());
    }

    @Test
    void reorder() {
        assertEquals(200, a.getQuantity());
        steve.reorder(a, 50);
        assertEquals(250,a.getQuantity());
    }

    @Test
    void updateSupplier() {
        assertEquals("woolworth", a.getSupplier());
        steve.updateSupplier(a, "coles");
        assertEquals("coles", a.getSupplier());
    }

    @Test
    void promote() {
        steve.promote(a,20);
        assertEquals(4.0, a.getSalePrice());
    }

    @Test
    void bulkDiscount() {
        assertEquals(5, a.getUnitPrice());
        steve.bulkDiscount(a, 200, 25);
        assertEquals(3.75, a.getBulkPrice());
    }

    @Test
    void setReplenishQuantity() {
        steve.setReplenishQuantity(a, 50);
        assertEquals(50, a.getReplenishQuantity());
    }

    @Test
    void checkStock() {
        a.setQuantity(10);
        assertEquals(10, a.getQuantity());
        steve.checkStock(a);
        assertEquals(100,a.getReplenishQuantity());
        assertEquals(110,a.getQuantity());
    }

    @Test
    void replenish() {


    }
}